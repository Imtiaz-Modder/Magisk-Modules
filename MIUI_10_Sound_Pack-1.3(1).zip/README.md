# MIUI 10 SYSTEMLESS SOUNDS

**Attention!** Some sounds have to be set manually through settings such as your default alarm sound, default notifications sound, and Phone ringtone!

UI Sounds are replaced automatically.

Some alarm sounds/ringtones may appear repeated in the ringtone chooser, I think it depends on your rom.

Changelog 

26/05/21

-Added new directories, update to v20 templete

17/05/19

-Update to v19 module templete

22/11/18

-Fix some sound directories

-Rename charging sound
