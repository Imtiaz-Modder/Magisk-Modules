## BUG REPORTS AND FEATURE REQUESTS

The best place is the issues template, anyway, search if your bug/feature request is already present, also in closed issues, if not create your own issue.
Try to be clear, without requiring me to pick for other details.

## PULL REQUESTS

Firstly try to open an issue, since I might not like your idea, so I would be sorry if you spent time on something that I don't want to merge.
