#!/system/bin/sh
pkill -9 -f /djs.sh
exit 0
