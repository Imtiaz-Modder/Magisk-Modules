# Set what you want to display when installing your module

print_modname() {
  ui_print "*****************************************"
  ui_print "           MIUI 10 SOUNDS PACK    "
  ui_print "   Extracted and Packed by 4PERTURE   "
  ui_print "******************************************"
}
