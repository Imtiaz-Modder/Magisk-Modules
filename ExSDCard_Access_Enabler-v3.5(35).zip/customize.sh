if [ "$API" -ge "26" ]; then
	echo -e "This module is NOT recommended for devices that running\nAndroid 8.0+ (Oreo)"
fi
